import BoilerplateItemBase from "./base-item.mjs";

export default class BoilerplateFeature extends BoilerplateItemBase {}